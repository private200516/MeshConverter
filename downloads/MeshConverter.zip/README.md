# MeshConverter — portable Windows release / 便携版

Extract the entire archive to a writable local folder, keep its directory layout,
then run `MeshConverter.exe`. Python, the required vendor packages, all WebView2
loader architectures, the reviewed vendor patch and third-party notices are
included. Windows x64 and an available Microsoft Edge WebView2 Runtime are needed.
Use a separate output folder and keep backups of your own input resources.

请完整解压后运行 `MeshConverter.exe`，不要单独移动 EXE 或删除随附依赖。
请使用独立输出目录，并保留自有输入资源的备份。

The evidence covers bounded automated regression checks and synthetic NIF
forward/reverse workflows. It does not establish compatibility with every mod,
native game corpus, gameplay, visual fidelity, performance or complete security.
上述检查范围有限，不代表所有模组、原生游戏资源、游戏内表现、性能或完整安全性均已验证。

Retained runtime, program, UI and asset files are byte-identical to the pinned B6
source archive. Build logs, private audit/provenance records and old reports are
not included. See `PUBLIC_MANIFEST.json`, `SHA256SUMS.txt`, `LICENSE`,
`THIRD_PARTY.md`, `licenses/` and the vendor package license metadata.
Do not redistribute game assets or other material without appropriate rights.
请遵守随附许可证；游戏资源及其他素材的使用和再分发权须由使用者自行确认。
