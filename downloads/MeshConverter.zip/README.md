# MeshConverter — ALPHA 1.0

> **最新动效版本 / Latest motion revision:** 2026-11-17 Pinterest motion. 启动 1400ms、关闭 650ms；323 项回归通过。详见 [MOTION_REVISION_20261117.md](MOTION_REVISION_20261117.md)。

Author: private0516 · Developed with GPT-6 Astra · AI-generated code and UI

## 2026-11-17 运行修复与动效更新

优化预览绘制与休眠、对话框/页签切换、日志飞入及滚动锚点。 启动器和随附运行库保留；应用源文件已更新。本包并非与旧 B6 发布包逐字节相同。

完整解压后运行同名 EXE，保留 app/、runtime/、vendor/ 及许可证目录。需要 Windows x64；Mesh 还需要已安装的 Microsoft Edge WebView2 Runtime。请使用独立输出目录。

两个程序独立运行、分别下载。已打开的旧窗口需要重新启动后才能加载更新。详见 VALIDATION_20261117.md。

测试使用合成 NIF、BGSM/BGEM 和小尺寸 DDS；没有复测广泛游戏资产或游戏内表现。反向 Texture 仅验证材质。Mesh 预览帧率是同机 Chrome 测试结果，Qt 的 16ms 调度也不代表任何负载下都稳定达到 60fps。

Extract the entire archive and run MeshConverter.exe. Keep all accompanying folders. This is the local 2026-11-17 motion revision, still ALPHA 1.0. Application files were updated; the launcher and dependency runtime are retained. See VALIDATION_20261117.md for validation scope. This archive is not byte-identical to the earlier B6 publication.

See LICENSE, THIRD_PARTY.md, licenses/ and dependency metadata for the existing project and third-party notices. No game fixtures are included in this update.

## 完整动画设置更新 / Full-motion update — 2026-11-17

Mesh 已移除“减少动态效果”设置，清除旧的该项偏好，并完整播放程序动画。系统减少动画偏好不再锁定本程序的动画；后台、失焦及关闭预览旋转时的暂停机制保留。

The reduced-motion option has been removed from Mesh Converter. The old preference is cleared and full application animations remain enabled even when the operating system requests reduced motion. Background rendering pauses and the separate model-rotation setting continue to work.
